# Exercícios Resolvidos - Introdução ao Flutter Framework (BRADEMO)

Este repositório contém a resolução de todas as atividades propostas ao final dos slides da **Aula 2 (BRADEMO) - Introdução ao Flutter Framework** [0.1.1, 0.1.2].

## 📌 Conteúdo das Atividades

### 1. Exercício 1: Container e Cores [0.1.39]
- **Descrição:** Reprodução da interface gráfica contendo um `Container` centralizado de cor laranja (`Colors.deepOrange`) com o texto "Hi Mom" e um ícone de sol (`Icons.wb_sunny`) alinhados lado a lado dentro de uma `Row` [0.1.39].
- **Arquivo:** `exercicio_1.dart`

### 2. Exercício 2: Barra de Botões [0.1.40]
- **Descrição:** Implementação de uma barra de ações (`CALL`, `ROUTE`, `SHARE`) utilizando layouts verticais e horizontais compostos por `Row`, `Column`, `Icon` e `Text` [0.1.40].
- **Arquivo:** `exercicio_2.dart`

### 3. Exercício 3: Stack & Positioned Widget [0.1.41]
- **Descrição:** Criação de uma tela que sobrepõe `Containers` coloridos em pilha (Verde, Vermelho e Roxo) utilizando os componentes `Stack` e `Positioned` para coordenar o posicionamento absoluto [0.1.41].
- **Arquivo:** `exercicio_3.dart`

### 4. Exercício 4: Inserção de Imagens e SizedBox [0.1.42]
- **Descrição:** Exibição de duas imagens de tamanhos diferentes (uma inferior) separadas e espaçadas por um componente `SizedBox`, utilizando `FittedBox` para tratar o redimensionamento dinâmico [0.1.42].
- **Arquivo:** `exercicio_4.dart`

### 5. Exercício 5: Tutorial de Layout do Flutter [0.1.43]
- **Descrição:** Implementação completa da tela de exemplo oficial do Flutter Layout (Campground em Oeschinen Lake), que integra seções de imagem, título com contador de estrelas, barra de botões estilizada e bloco de texto descritivo [0.1.43].
- **Arquivo:** `exercicio_5.dart`

---

## 🛠️ Como Executar os Projetos

Cada script contém a função `main()` isolada e pronta para execução. Você pode copiar o código de qualquer arquivo e substituir no arquivo `lib/main.dart` de um projeto Flutter recém-criado [0.1.6]:

```bash
# Criar um novo projeto Flutter (se necessário)
flutter create brademo_atividades

# Executar o projeto no emulador ou dispositivo conectado
flutter run
```

Prof. Luiz Gustavo Diniz de Oliveira Véras - IFSP [0.1.1]
