import 'package:flutter/material.dart';

void main() => runApp(const MaterialApp(
      home: Exercicio4(),
      debugShowCheckedModeBanner: false,
    ));

class Exercicio4 extends StatelessWidget {
  const Exercicio4({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Insert Image Example'),
        backgroundColor: Colors.blue,
      ),
      body: ListView(
        padding: const EdgeInsets.all(16.0),
        children: [
          // Primeira Imagem (Utilizando FittedBox para redimensionamento se necessário)
          Container(
            height: 200,
            child: FittedBox(
              fit: BoxFit.cover,
              child: Image.network(
                'https://picsum.photos/id/1015/600/400',
              ),
            ),
          ),
          const SizedBox(height: 30), // Espaçamento solicitado via SizedBox
          // Segunda Imagem (De tamanho inferior)
          Container(
            height: 120,
            child: FittedBox(
              fit: BoxFit.contain,
              child: Image.network(
                'https://picsum.photos/id/1016/300/200',
              ),
            ),
          ),
        ],
      ),
    );
  }
}
