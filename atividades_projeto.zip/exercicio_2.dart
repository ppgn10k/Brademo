import 'package:flutter/material.dart';

void main() => runApp(const MaterialApp(
      home: Exercicio2(),
      debugShowCheckedModeBanner: false,
    ));

class Exercicio2 extends StatelessWidget {
  const Exercicio2({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20.0),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              _buildButtonColumn(Icons.call, 'CALL', Colors.deepPurple),
              _buildButtonColumn(Icons.near_me, 'ROUTE', Colors.deepPurple),
              _buildButtonColumn(Icons.share, 'SHARE', Colors.deepPurple),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildButtonColumn(IconData icon, String label, Color color) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Icon(icon, color: color, size: 36),
        const SizedBox(height: 8),
        Text(
          label,
          style: TextStyle(
            fontSize: 14,
            fontWeight: FontWeight.w400,
            color: color,
          ),
        ),
      ],
    );
  }
}
