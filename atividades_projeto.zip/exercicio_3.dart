import 'package:flutter/material.dart';

void main() => runApp(const MaterialApp(
      home: Exercicio3(),
      debugShowCheckedModeBanner: false,
    ));

class Exercicio3 extends StatelessWidget {
  const Exercicio3({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Stack & Positioned Widget'),
        backgroundColor: Colors.blue,
      ),
      body: Center(
        child: SizedBox(
          width: 300,
          height: 400,
          child: Stack(
            children: [
              Positioned(
                top: 20,
                left: 20,
                child: Container(
                  width: 200,
                  height: 200,
                  color: Colors.green,
                  padding: const EdgeInsets.all(8),
                  child: const Text('Green', style: TextStyle(color: Colors.white)),
                ),
              ),
              Positioned(
                top: 50,
                left: 50,
                child: Container(
                  width: 200,
                  height: 200,
                  color: Colors.red,
                  padding: const EdgeInsets.all(8),
                  child: const Text('Red', style: TextStyle(color: Colors.white)),
                ),
              ),
              Positioned(
                top: 80,
                left: 80,
                child: Container(
                  width: 180,
                  height: 180,
                  color: Colors.purple,
                  padding: const EdgeInsets.all(8),
                  child: const Text('Purple', style: TextStyle(color: Colors.white)),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
