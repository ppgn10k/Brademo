import 'package:flutter/material.dart';

void main() => runApp(const MaterialApp(
      home: Exercicio1(),
      debugShowCheckedModeBanner: false,
    ));

class Exercicio1 extends StatelessWidget {
  const Exercicio1({Key? key}) : SizeField(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Flutter is Fun!'),
        backgroundColor: Colors.green,
      ),
      body: Center(
        child: Container(
          width: 150,
          height: 150,
          color: Colors.deepOrange,
          child: const Center(
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(
                  'Hi Mom ',
                  style: TextStyle(color: Colors.white, fontSize: 18),
                ),
                Icon(
                  Icons.wb_sunny,
                  color: Colors.white,
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
