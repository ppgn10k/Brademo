class Laptop {
  int id;
  String nome;
  int ram;
  double clockCpu;

  Laptop(this.id, this.nome, this.ram, this.clockCpu);

  // Configuração para somente navegação na internet.
  Laptop.navegacao()
      : id = 1,
        nome = "Laptop para Navegação",
        ram = 4,
        clockCpu = 2.0;

  // Configuração para uso em escritório.
  Laptop.escritorio()
      : id = 2,
        nome = "Laptop para Escritório",
        ram = 8,
        clockCpu = 2.5;

  // Configuração para programação.
  Laptop.programacao()
      : id = 3,
        nome = "Laptop para Programação",
        ram = 16,
        clockCpu = 3.2;

  void imprimirDetalhes() {
    print("ID: $id");
    print("Nome: $nome");
    print("RAM: $ram GB");
    print("Clock CPU: $clockCpu GHz");
  }
}

void main() {
  Laptop laptopInternet = Laptop.navegacao();
  Laptop laptopEscritorio = Laptop.escritorio();
  Laptop laptopProgramacao = Laptop.programacao();

  print("===== NAVEGAÇÃO NA INTERNET =====");
  laptopInternet.imprimirDetalhes();

  print("\n===== USO EM ESCRITÓRIO =====");
  laptopEscritorio.imprimirDetalhes();

  print("\n===== PROGRAMAÇÃO =====");
  laptopProgramacao.imprimirDetalhes();
}
