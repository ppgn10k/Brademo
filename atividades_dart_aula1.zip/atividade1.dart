void main() {
  // var infere o tipo a partir do valor inicial.
  // Como nomeEquipamento recebe uma String, seu tipo é String.
  var nomeEquipamento = "Impressora 3D";

  // String define explicitamente o tipo da variável.
  // Por isso, local não pode receber outro tipo de valor.
  String local = "Lab de Protótipos";

  // dynamic permite que o tipo do valor seja alterado durante a execução.
  dynamic patrimonio = 12345;

  // patrimonio agora passa de int para String.
  patrimonio = "12345-A";

  print("Nome do equipamento: $nomeEquipamento");
  print("Local: $local");
  print("Patrimônio: $patrimonio");

  print("nomeEquipamento é String: ${nomeEquipamento is String}");
  print("local é String: ${local is String}");
  print("patrimonio é String: ${patrimonio is String}");
}
