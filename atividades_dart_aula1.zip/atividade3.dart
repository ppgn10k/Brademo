class Laptop {
  int id;
  String nome;
  int ram;
  double clockCpu;

  Laptop(this.id, this.nome, this.ram, this.clockCpu);

  void imprimirDetalhes() {
    print("ID: $id");
    print("Nome: $nome");
    print("RAM: $ram GB");
    print("Clock CPU: $clockCpu GHz");
  }
}

void main() {
  Laptop laptop1 = Laptop(1, "Dell Inspiron", 8, 2.4);
  Laptop laptop2 = Laptop(2, "Lenovo IdeaPad", 16, 3.0);
  Laptop laptop3 = Laptop(3, "Acer Aspire", 8, 2.8);

  print("===== LAPTOP 1 =====");
  laptop1.imprimirDetalhes();

  print("\n===== LAPTOP 2 =====");
  laptop2.imprimirDetalhes();

  print("\n===== LAPTOP 3 =====");
  laptop3.imprimirDetalhes();
}
