import 'dart:io';

class House {
  int id;
  String name;
  double price;

  // Construtor utilizando this para inicializar os atributos.
  House(this.id, this.name, this.price);
}

void main() {
  List<House> casas = [];

  // Cadastro de 3 casas.
  for (int i = 0; i < 3; i++) {
    print("\n===== CADASTRO DA CASA ${i + 1} =====");

    print("Digite o ID:");
    int id = int.parse(stdin.readLineSync()!);

    print("Digite o nome da casa:");
    String name = stdin.readLineSync()!;

    print("Digite o preço da casa:");
    double price = double.parse(stdin.readLineSync()!);

    House casa = House(id, name, price);
    casas.add(casa);
  }

  // Cascade notation (..) para alterar o nome de cada casa.
  for (var casa in casas) {
    casa..name = "${casa.name} (Cadastrada)";
  }

  print("\n===== CASAS CADASTRADAS =====");

  // for-in para imprimir todos os detalhes.
  for (var casa in casas) {
    print("ID: ${casa.id}");
    print("Nome: ${casa.name}");
    print("Preço: R$ ${casa.price.toStringAsFixed(2)}");
    print("-----------------------------");
  }
}
